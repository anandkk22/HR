import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { createEmployeecanDeactivateGuardService } from './employee/services/create-employee-can-deactivate-gaurd.service';
import { EmployeeDetailsComponent } from './employee/employee-details.component';


const routes: Routes = [
  {path: 'list', component: EmployeeListComponent},
  {path: 'employee/:id', component: EmployeeDetailsComponent},
  {path: 'create', component: CreateEmployeeComponent, 
  canDeactivate: [createEmployeecanDeactivateGuardService]},
  {path:'', redirectTo:'list', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
