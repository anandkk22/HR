import { Component, OnInit, ViewChild } from '@angular/core';
import { Employee } from './model/employee.model';
import { NgForm } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Department } from './model/department.model';
import { Router } from '@angular/router';
import { EmployeeService } from './services/employee.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  @ViewChild('employeeForm', { static: false }) public createEmployeeForm: NgForm;
  listEmployees: Employee[];
  dateFormatConfig: Partial<BsDatepickerConfig>
  employee: Employee = {
    id: null,
    fullName: null,
    gender: null,
    email: null,
    contactPreference: null,
    phoneNumber: null,
    dateofBirth: null,
    department: null,
    isActive: null,
    photoPath: null,
  };
  departments: Department[] = [
    { id: 1, name: 'HR' },
    { id: 2, name: 'Admin' },
    { id: 3, name: 'IT' },
    { id: 4, name: 'Accounts' },
    { id: 5, name: 'Finance' }
  ];

  previewPhoto = false;

  constructor(private _route: Router, private employeeService: EmployeeService) {
    this.dateFormatConfig = Object.assign({}, { containerClass: 'theme-dark-blue', dateInputFormat: 'DD/MM/YYYY' })
  }

  ngOnInit() {
  }

  saveEmployee(): void {
    const newEmploye = Object.assign({}, this.employee);
    this.employeeService.save(newEmploye);
    this.createEmployeeForm.reset();
    this._route.navigate(['/list']);
  }

  togglePhoto() {
    this.previewPhoto = !this.previewPhoto;
  }

}
