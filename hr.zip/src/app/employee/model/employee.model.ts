export class Employee {
    id: number;
    fullName: string;
    gender: string;
    email: string;
    contactPreference: string;
    phoneNumber: number;
    dateofBirth: Date;
    department: string;
    isActive: boolean;
    photoPath: string;
}