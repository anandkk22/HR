import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Employee } from './model/employee.model';
import { EmployeeService } from './services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: Employee[];
  filteredEmployees: Employee[];
  // searchTerm: string;
  private _searchTerm: string;

  get searchTerm(): string {
    return this._searchTerm
  }

  set searchTerm(val: string) {
    this._searchTerm = val;
    this.filteredEmployees = this.filterEmployees(val)
  }

  filterEmployees(searchString: string) {
    return this.employees.filter(employee =>
      employee.fullName.toLowerCase().indexOf(searchString.toLowerCase()) !== -1)
  }



  constructor(private _employeeService: EmployeeService, private router: Router) { }

  ngOnInit() {
    this.employees = this._employeeService.getEmployees();
  }

  getEmployee(id: number) {
    this.router.navigate(['/employee', id]);
  }


}

