import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';

@Injectable()
export class EmployeeService {
    private listemployees: Employee[] = [
        {
            id: 1,
            fullName: 'aaa',
            gender: 'male',
            email: 'a@a.com',
            contactPreference: 'email',
            phoneNumber: 333333,
            dateofBirth: new Date('1/1/2014'),
            department: 'HR',
            isActive: true,
            photoPath: 'assets/images/1.jpg'
        },
        {
            id: 2,
            fullName: 'bbb',
            gender: 'female',
            email: 'b@d.com',
            contactPreference: 'phoneNumber',
            phoneNumber: 333333,
            dateofBirth: new Date('12/11/2013'),
            department: 'Accounts',
            isActive: true,
            photoPath: 'assets/images/2.png'
        },
        {
            id: 3,
            fullName: 'ccc',
            gender: 'male',
            email: 'ac@c.com',
            contactPreference: 'email',
            phoneNumber: 333333,
            dateofBirth: new Date('10/6/2014'),
            department: 'Finance',
            isActive: true,
            photoPath: 'assets/images/3.png'
        },
    ]

    getEmployees(): Employee[] {
        return this.listemployees;
    }

    save(employee: Employee){
        this.listemployees.push(employee);
    }

    getEmployee(id: number): Employee {
        return this.listemployees.find(e => e.id == id);
    }
}