import { PipeTransform, Pipe } from '@angular/core';
import { Employee } from '../model/employee.model';

@Pipe({
    name: 'employeeFilter'
})
export class employeeFilterPipe implements PipeTransform {
    transform(employees: Employee[], searchTerm: string): Employee[] {
        if (!employees || !searchTerm) {
            return employees;
        }

        return employees.filter(employees =>
            employees.fullName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1)
    }
}
