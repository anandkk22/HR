import { Component, OnInit } from '@angular/core';
import { Employee } from './model/employee.model';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from './services/employee.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  private _id: number;
  employee: Employee;

  constructor(private _router: ActivatedRoute, private employeeSerice: EmployeeService, private route: Router) { }

  ngOnInit() {
    this._router.paramMap.subscribe(params => {
      this._id =  +params.get('id');
      this.employee = this.employeeSerice.getEmployee(this._id);
    });
  }

  viewNextEmployee() {
    if(this._id < 3){
      this._id = this._id + 1;
    } else {
      this._id =1;
    }
    this.route.navigate(['/employee', this._id])
  }

}
