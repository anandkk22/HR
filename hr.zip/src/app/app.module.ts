import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { SelectRequiredValidatorDirective } from './employee/shared/defaultSelection-directive';
import { confirmEqualValidatorDirective } from './employee/shared/confirm-equal-validator.directive';
import { EmployeeService } from './employee/services/employee.service';
import { DisplayEmployeeComponent } from './employee/display-employee.component';
import { createEmployeecanDeactivateGuardService } from './employee/services/create-employee-can-deactivate-gaurd.service';
import { EmployeeDetailsComponent } from './employee/employee-details.component';
import { employeeFilterPipe } from './employee/shared/employee-filter.pipe';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    CreateEmployeeComponent,
    SelectRequiredValidatorDirective,
    confirmEqualValidatorDirective,
    DisplayEmployeeComponent,
    EmployeeDetailsComponent,
    employeeFilterPipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  ],
  providers: [EmployeeService, createEmployeecanDeactivateGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
